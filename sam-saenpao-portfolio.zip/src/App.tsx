/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { 
  Github, 
  Mail, 
  Linkedin, 
  Menu,
  X,
  Download,
  ArrowRight,
  ChevronDown,
  Instagram,
  Facebook,
  ExternalLink,
  Layers,
  Box,
  PenTool,
  Maximize2,
  FileText,
  Briefcase,
  GraduationCap
} from 'lucide-react';

// --- Types ---
interface Project {
  id: number;
  title: string;
  location: string;
  year: string;
  image: string;
  category: string;
  role: string;
  description: string;
}

interface Experience {
  year: string;
  title: string;
  company: string;
  description: string;
}

// --- Constants ---
const PROJECTS: Project[] = [
  {
    id: 1,
    title: "The Vertical Garden",
    location: "Sydney, Australia",
    year: "2023",
    image: "https://picsum.photos/seed/architecture-garden/1600/1000",
    category: "Residential",
    role: "3D Modelling / Technical Documentation",
    description: "A high-density residential project focused on biophilic integration and sustainable cooling systems."
  },
  {
    id: 2,
    title: "Pavilion of Light",
    location: "Singapore",
    year: "2022",
    image: "https://picsum.photos/seed/architecture-pavilion/1600/1000",
    category: "Public",
    role: "Design Development / Rhino Modelling",
    description: "An experimental public space exploring the intersection of parametric geometry and natural light."
  },
  {
    id: 3,
    title: "Urban Nexus",
    location: "Tokyo, Japan",
    year: "2021",
    image: "https://picsum.photos/seed/architecture-urban/1600/1000",
    category: "Commercial",
    role: "Drafting / BIM Coordination",
    description: "A mixed-use commercial hub designed for high-efficiency circulation and modular growth."
  },
  {
    id: 4,
    title: "Stone & Spirit",
    location: "Kyoto, Japan",
    year: "2020",
    image: "https://picsum.photos/seed/architecture-stone/1600/1000",
    category: "Culture",
    role: "Concept Design / SketchUp Visualization",
    description: "A cultural center that reinterprets traditional Japanese joinery through modern materiality."
  }
];

const EXPERIENCE: Experience[] = [
  {
    year: "2022 — Present",
    title: "Architectural Drafter",
    company: "Studio Horizon, Sydney",
    description: "Leading technical documentation and 3D visualization for large-scale residential developments."
  },
  {
    year: "2020 — 2022",
    title: "Junior Designer",
    company: "EcoArch Associates",
    description: "Assisted in concept development and planning applications for sustainable housing projects."
  },
  {
    year: "2017 — 2020",
    title: "Bachelor of Architecture",
    company: "University of Technology Sydney (UTS)",
    description: "Graduated with honors, focusing on computational design and urban ecology."
  }
];

const PROCESS_STEPS = [
  {
    title: "Research & Site",
    description: "Deep dive into context, climate, and constraints to build a solid foundation.",
    icon: <Maximize2 className="w-6 h-6" />
  },
  {
    title: "Concept Exploration",
    description: "Iterative sketching and massing to find the core design narrative.",
    icon: <PenTool className="w-6 h-6" />
  },
  {
    title: "3D Development",
    description: "Refining forms in Rhino and SketchUp to test spatial qualities.",
    icon: <Box className="w-6 h-6" />
  },
  {
    title: "Technical Documentation",
    description: "Precision drafting in AutoCAD to ensure buildability and clarity.",
    icon: <Layers className="w-6 h-6" />
  }
];

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Projects', href: '#projects' },
    { name: 'About', href: '#about' },
    { name: 'Process', href: '#process' },
    { name: 'Resume', href: '#resume' },
    { name: 'Journal', href: '#journal' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-1000 ${isScrolled ? 'bg-white/80 backdrop-blur-xl py-4 shadow-sm' : 'bg-transparent py-10'}`}>
      <div className="max-w-[1400px] mx-auto px-8 flex items-center justify-between">
        <motion.a 
          href="#" 
          className="text-2xl font-display font-medium tracking-tight text-stone-800"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          SAM SAENPAO
        </motion.a>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-10">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-[10px] uppercase tracking-[0.3em] font-bold text-stone-400 hover:text-stone-900 transition-colors duration-500"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button 
          className="lg:hidden p-2 text-stone-900"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-white/95 backdrop-blur-md border-b border-stone-100 p-10 flex flex-col gap-6 lg:hidden shadow-xl"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                className="text-2xl font-display text-stone-800"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const ProjectItem = ({ project, index }: { project: Project, index: number, key?: React.Key }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 1.5, ease: [0.2, 0.8, 0.2, 1], delay: index * 0.1 }}
      className="group relative cursor-pointer mb-32 last:mb-0"
    >
      <div className="aspect-[16/9] overflow-hidden bg-stone-100 rounded-sm relative soft-shadow">
        <img 
          src={project.image} 
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-[3s] ease-out group-hover:scale-105"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 haze-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
        <div className="absolute top-6 right-6 px-4 py-2 bg-white/80 backdrop-blur-sm text-[9px] font-bold uppercase tracking-[0.2em] text-stone-900 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500">
          {project.category}
        </div>
      </div>
      <div className="mt-10 grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        <div className="md:col-span-8">
          <h3 className="text-3xl md:text-5xl font-display font-light mb-4 tracking-tight text-stone-800">{project.title}</h3>
          <p className="text-stone-500 font-light leading-relaxed max-w-2xl mb-6">
            {project.description}
          </p>
          <div className="flex flex-wrap gap-x-8 gap-y-2">
            <div className="flex flex-col">
              <span className="text-[9px] uppercase tracking-widest text-stone-300 font-bold mb-1">Role</span>
              <span className="text-xs text-stone-600 font-medium">{project.role}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[9px] uppercase tracking-widest text-stone-300 font-bold mb-1">Location</span>
              <span className="text-xs text-stone-600 font-medium">{project.location}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[9px] uppercase tracking-widest text-stone-300 font-bold mb-1">Year</span>
              <span className="text-xs text-stone-600 font-medium">{project.year}</span>
            </div>
          </div>
        </div>
        <div className="md:col-span-4 flex md:justify-end">
          <motion.div 
            className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.3em] text-stone-400 group-hover:text-stone-900 transition-colors"
            whileHover={{ x: 5 }}
          >
            Explore Project <ArrowRight className="w-4 h-4" />
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default function App() {
  const { scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 1.05]);
  const heroBlur = useTransform(scrollYProgress, [0, 0.2], [0, 10]);

  return (
    <div className="min-h-screen font-sans selection:bg-[#f3e5d0] selection:text-[#3d3a35]">
      <Navbar />

      <main>
        {/* Hero Section */}
        <section className="relative h-screen w-full overflow-hidden flex items-center justify-center text-center">
          <motion.div 
            className="absolute inset-0 -z-10"
            style={{ opacity: heroOpacity, scale: heroScale, filter: `blur(${heroBlur}px)` }}
          >
            <img 
              src="https://picsum.photos/seed/architecture-modern-morning/1920/1080" 
              alt="Architectural Render" 
              className="w-full h-full object-cover brightness-95"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#fdfaf6]/40" />
            <div className="absolute inset-0 volumetric-light" />
          </motion.div>
          
          <div className="max-w-5xl mx-auto px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 2, ease: [0.2, 0.8, 0.2, 1] }}
            >
              <h1 className="text-6xl md:text-9xl font-display font-light text-white leading-none tracking-tighter mb-10 golden-glow">
                SAM <span className="italic">SAENPAO</span>
              </h1>
              <div className="h-px w-24 bg-white/60 mx-auto mb-10" />
              <h2 className="text-xs md:text-sm uppercase tracking-[0.6em] text-white/90 font-bold mb-6">
                Architectural Designer & Drafter
              </h2>
              <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto leading-relaxed font-light tracking-wide">
                Crafting spaces through precision and imagination. 
                Capturing the soul of architecture in the morning light.
              </p>
            </motion.div>
          </div>

          <motion.div 
            className="absolute bottom-12 left-1/2 -translate-x-1/2 text-white/60 flex flex-col items-center gap-2"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <span className="text-[9px] uppercase tracking-[0.4em]">Explore</span>
            <ChevronDown className="w-4 h-4" />
          </motion.div>
        </section>

        {/* Design Approach / Philosophy */}
        <section id="approach" className="py-32 md:py-48 bg-[#fdfaf6]">
          <div className="max-w-[1000px] mx-auto px-8">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-16 items-start">
              <div className="md:col-span-4">
                <h2 className="text-xs uppercase tracking-[0.4em] font-bold text-stone-300 mb-8">Design Approach</h2>
              </div>
              <div className="md:col-span-8">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.5 }}
                >
                  <p className="text-2xl md:text-4xl font-display font-light text-stone-800 leading-tight mb-12">
                    "I believe in an architecture that is as technically sound as it is emotionally resonant."
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-12">
                    <div>
                      <h4 className="text-[11px] font-bold uppercase tracking-[0.2em] mb-4 text-stone-900">Precision-driven</h4>
                      <p className="text-sm text-stone-500 leading-relaxed font-light">
                        Every line in a drawing represents a physical reality. I focus on the clarity and accuracy of documentation.
                      </p>
                    </div>
                    <div>
                      <h4 className="text-[11px] font-bold uppercase tracking-[0.2em] mb-4 text-stone-900">3D Visualization</h4>
                      <p className="text-sm text-stone-500 leading-relaxed font-light">
                        Using Rhino and SketchUp to test spatial qualities and communicate complex ideas through immersive renders.
                      </p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section id="projects" className="pb-32 bg-[#fdfaf6]">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="mb-24 flex items-end justify-between border-b border-stone-100 pb-8">
              <h2 className="text-xs uppercase tracking-[0.4em] font-bold text-stone-300">Selected Works</h2>
              <div className="flex gap-8 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400">
                <button className="text-stone-900">All</button>
                <button className="hover:text-stone-900 transition-colors">Residential</button>
                <button className="hover:text-stone-900 transition-colors">Commercial</button>
                <button className="hover:text-stone-900 transition-colors">Conceptual</button>
              </div>
            </div>
            
            <div className="max-w-5xl mx-auto">
              {PROJECTS.map((project, idx) => (
                <ProjectItem key={project.id} project={project} index={idx} />
              ))}
            </div>

            <div className="mt-32 text-center">
              <motion.button 
                className="px-16 py-6 border border-stone-200 text-[10px] font-bold uppercase tracking-[0.4em] hover:bg-stone-900 hover:text-white transition-all duration-500"
                whileHover={{ scale: 1.02 }}
              >
                View Full Portfolio
              </motion.button>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-32 md:py-48 bg-[#f9f6f2]">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-24">
              <div className="lg:col-span-5">
                <div className="sticky top-32">
                  <h2 className="text-xs uppercase tracking-[0.4em] font-bold text-stone-300 mb-12">About Me</h2>
                  <h3 className="text-4xl md:text-6xl font-display font-light mb-10 tracking-tight leading-none text-stone-800">
                    Architectural <br />
                    Designer & <br />
                    <span className="italic">Drafter</span>
                  </h3>
                  <div className="aspect-[4/5] overflow-hidden rounded-sm grayscale mb-12 soft-shadow">
                    <img 
                      src="https://picsum.photos/seed/architecture-facade/1000/1250" 
                      alt="Architectural Detail" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>
              </div>
              <div className="lg:col-span-7 pt-12">
                <div className="max-w-2xl">
                  <div className="mb-24">
                    <h4 className="text-[11px] font-bold uppercase tracking-[0.3em] text-stone-900 mb-8">Personal Story</h4>
                    <p className="text-xl text-stone-500 leading-relaxed font-light mb-8">
                      A UTS Architecture graduate with a passion for the technical intricacies of design. 
                      With over 2 years of experience in professional firms, I've honed my skills in 
                      bridging the gap between conceptual sketches and construction-ready documentation.
                    </p>
                    <p className="text-lg text-stone-400 leading-relaxed font-light">
                      I thrive in the details—whether it's coordinating complex BIM models or 
                      refining the materiality of a facade. My goal is to grow into a versatile 
                      architect who understands every layer of the building process.
                    </p>
                  </div>

                  <div>
                    <h4 className="text-[11px] font-bold uppercase tracking-[0.3em] text-stone-900 mb-12">Design Values</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-12">
                      <div>
                        <h5 className="text-xs font-bold uppercase tracking-widest mb-4">Clarity in Drawings</h5>
                        <p className="text-sm text-stone-500 font-light leading-relaxed">Ensuring that every plan and section communicates intent without ambiguity.</p>
                      </div>
                      <div>
                        <h5 className="text-xs font-bold uppercase tracking-widest mb-4">Functional Efficiency</h5>
                        <p className="text-sm text-stone-500 font-light leading-relaxed">Designing spaces that work seamlessly for the people who inhabit them.</p>
                      </div>
                      <div>
                        <h5 className="text-xs font-bold uppercase tracking-widest mb-4">Aesthetic Balance</h5>
                        <p className="text-sm text-stone-500 font-light leading-relaxed">Finding the harmony between organic forms and structured geometry.</p>
                      </div>
                      <div>
                        <h5 className="text-xs font-bold uppercase tracking-widest mb-4">Environmental Awareness</h5>
                        <p className="text-sm text-stone-500 font-light leading-relaxed">Integrating sustainable principles from the earliest concept stages.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section id="process" className="py-32 md:py-48 bg-[#fdfaf6] overflow-hidden">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="mb-24 text-center">
              <h2 className="text-xs uppercase tracking-[0.4em] font-bold text-stone-300 mb-8">My Design Process</h2>
              <h3 className="text-4xl md:text-6xl font-display font-light tracking-tight text-stone-800">From Vision to Detail</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
              {PROCESS_STEPS.map((step, idx) => (
                <motion.div 
                  key={step.title}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1, delay: idx * 0.2 }}
                  className="p-10 border border-stone-100 hover:border-stone-900 transition-colors duration-700 group bg-white/50 backdrop-blur-sm"
                >
                  <div className="text-stone-300 group-hover:text-stone-900 transition-colors duration-500 mb-8">
                    {step.icon}
                  </div>
                  <span className="text-[10px] font-mono text-stone-200 mb-4 block">0{idx + 1}</span>
                  <h4 className="text-lg font-display font-medium mb-4 text-stone-800">{step.title}</h4>
                  <p className="text-sm text-stone-400 font-light leading-relaxed">{step.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Resume Section */}
        <section id="resume" className="py-32 md:py-48 bg-[#3d3a35] text-white">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-24">
              <div className="lg:col-span-4">
                <h2 className="text-xs uppercase tracking-[0.4em] font-bold text-stone-500 mb-12">Resume</h2>
                <h3 className="text-4xl md:text-6xl font-display font-light mb-12 tracking-tight">Experience & <br />Education</h3>
                <motion.a 
                  href="/resume.pdf" 
                  download
                  className="inline-flex items-center gap-4 px-10 py-5 bg-[#fdfaf6] text-[#3d3a35] text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-stone-200 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Download className="w-4 h-4" />
                  Download CV
                </motion.a>
              </div>
              <div className="lg:col-span-8">
                <div className="space-y-16">
                  {EXPERIENCE.map((exp, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 1 }}
                      className="grid grid-cols-1 md:grid-cols-12 gap-6 border-b border-stone-700 pb-12 last:border-0"
                    >
                      <div className="md:col-span-3">
                        <span className="text-xs font-mono text-stone-500">{exp.year}</span>
                      </div>
                      <div className="md:col-span-9">
                        <h4 className="text-xl font-display font-medium mb-2">{exp.title}</h4>
                        <h5 className="text-sm text-stone-400 uppercase tracking-widest mb-4">{exp.company}</h5>
                        <p className="text-stone-500 font-light leading-relaxed max-w-xl">{exp.description}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Journal Preview */}
        <section id="journal" className="py-32 bg-[#fdfaf6]">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="flex items-end justify-between mb-24 border-b border-stone-100 pb-8">
              <h2 className="text-xs uppercase tracking-[0.4em] font-bold text-stone-300">Journal</h2>
              <a href="#" className="text-[10px] font-bold uppercase tracking-[0.2em] text-stone-400 hover:text-stone-900 transition-colors">View All Entries</a>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {[1, 2, 3].map(i => (
                <div key={i} className="group cursor-pointer">
                  <div className="aspect-square overflow-hidden bg-stone-100 mb-8 soft-shadow">
                    <img 
                      src={`https://picsum.photos/seed/architecture-detail-${i}/800/800`} 
                      alt="Journal Entry" 
                      className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className="text-[9px] font-mono text-stone-300 mb-4 block">MARCH 0{i}, 2024</span>
                  <h4 className="text-xl font-display font-light mb-4 group-hover:text-stone-500 transition-colors text-stone-800">
                    {i === 1 ? "Workflow: Parametric Facades in Rhino" : i === 2 ? "The Importance of Line Weights in Documentation" : "Sketching the Organic: A Weekend Study"}
                  </h4>
                  <p className="text-sm text-stone-400 font-light leading-relaxed line-clamp-2">
                    Exploring the intersection of geometry and materiality through digital tools and hand sketches.
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer id="contact" className="py-24 bg-[#f9f6f2] text-stone-900">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-display font-medium tracking-tight mb-8">SAM SAENPAO</h2>
              <p className="text-stone-400 max-w-sm leading-relaxed mb-8 font-light">
                Architectural Designer & Drafter based in Sydney, Australia. 
                Available for freelance projects and collaborations.
              </p>
              <div className="flex gap-6 text-stone-300">
                <a href="#" className="hover:text-stone-900 transition-colors"><Instagram className="w-5 h-5" /></a>
                <a href="#" className="hover:text-stone-900 transition-colors"><Facebook className="w-5 h-5" /></a>
                <a href="#" className="hover:text-stone-900 transition-colors"><Linkedin className="w-5 h-5" /></a>
                <a href="#" className="hover:text-stone-900 transition-colors"><Github className="w-5 h-5" /></a>
              </div>
            </div>
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-stone-300 mb-8">Location</h4>
              <ul className="text-xs font-medium uppercase tracking-widest space-y-4 text-stone-500">
                <li>Sydney, Australia</li>
                <li>Surry Hills Studio</li>
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-stone-300 mb-8">Contact</h4>
              <ul className="text-xs font-medium uppercase tracking-widest space-y-4 text-stone-500">
                <li>sam@saenpao.com</li>
                <li>LinkedIn / SamSaenpao</li>
                <li>Instagram / @sam_arch</li>
              </ul>
            </div>
          </div>
          <div className="pt-12 border-t border-stone-100 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] font-bold uppercase tracking-[0.3em] text-stone-300">
            <p>© {new Date().getFullYear()} SAM SAENPAO. ALL RIGHTS RESERVED.</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-stone-900 transition-colors">Privacy</a>
              <a href="#" className="hover:text-stone-900 transition-colors">Terms</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
